$(function(){
    
    $('.h-type .btngroup button').click(function(){
        
        console.log($(this).index())
        
    })
    
})